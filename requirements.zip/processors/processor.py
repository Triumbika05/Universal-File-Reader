from PyPDF2 import PdfReader
import csv
import json
import xml.etree.ElementTree as ET
from config import SUPPORTED_FILE_TYPES



# Step 1: Detect file type
def detect_file_type(file_name):
    if file_name.endswith(".csv"):
        return "csv"
    elif file_name.endswith(".json"):
        return "json"
    elif file_name.endswith(".txt"):
        return "txt"
    elif file_name.endswith(".xml"):
        return "xml"
    elif file_name.endswith(".pdf"):
        return "pdf"
    else:
        return "unknown"

# Step 2A: Process CSV
def process_csv(file_path):
    data = []

    with open(file_path, 'r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            data.append(row)

    return data


# Step 2B: Process TXT
def process_txt(file_path):
    data = []

    with open(file_path, 'r') as file:
        for line in file:
            parts = line.strip().split(",")

            if len(parts) == 3:
                data.append({
                    "name": parts[0],
                    "age": parts[1],
                    "city": parts[2]
                })

    return data


# Step 2C: Process XML
def process_xml(file_path):
    data = []

    tree = ET.parse(file_path)
    root = tree.getroot()

    for emp in root.findall("employee"):
        record = {
            "name": emp.find("name").text,
            "age": emp.find("age").text,
            "city": emp.find("city").text
        }
        data.append(record)

    return data
def process_pdf(file_path):
    data = []

    reader = PdfReader(file_path)

    for page_num, page in enumerate(reader.pages):
        text = page.extract_text()

        if text:
            lines = text.split("\n")

            for line in lines:
                line = line.strip()

                if line:  # avoid empty lines
                    data.append({
                        "page": page_num + 1,
                        "content": line
                    })

    return data


PROCESSOR_MAP = {
    "csv": process_csv,
    "txt": process_txt,
    "xml": process_xml,
    "pdf": process_pdf
}
# Step 3: Create final output
# def create_output(file_name, data):
#     output = {
#         "file_name": file_name,
#         "data": data
#     }

#     with open("output.json", "w") as f:
#         json.dump(output, f, indent=4)

#     print("✅ JSON output created")
# import os

# def create_output(file_name, data):
#     base_name = os.path.splitext(file_name)[0]   # removes extension

#     output_file = f"{base_name}_output.json"

#     output = {
#         "file_name": file_name,
#         "data": data
#     }

#     with open(output_file, "w") as f:
#         json.dump(output, f, indent=4)

#     print(f"✅ JSON output created: {output_file}")

def create_output(file_name, data):
    import os
    import json

    base_name = os.path.splitext(file_name)[0]
    output_file = f"{base_name}_output.json"

    output = {
        "file_name": file_name,
        "data": data
    }

    with open(output_file, "w") as f:
        json.dump(output, f, indent=4)

    print(f"✅ JSON output created: {output_file}")

    return output_file   # ✅ ADD THIS

# Step 4: Main function
# def main():
#     file_name = "employee_data.csv"   # 🔁 Change this to test different files

#     file_type = detect_file_type(file_name)

#     if file_type == "csv":
#         data = process_csv(file_name)

#     elif file_type == "txt":
#         data = process_txt(file_name)

#     elif file_type == "xml":
#         data = process_xml(file_name)
#     elif file_type == "pdf":
#         data = process_pdf(file_name)
#     else:
#         print("❌ Unsupported file type")
#         return

#     create_output(file_name, data)

# def main(file_name):
#     file_type = detect_file_type(file_name)

#     if file_type == "csv":
#         data = process_csv(file_name)

#     elif file_type == "txt":
#         data = process_txt(file_name)

#     elif file_type == "xml":
#         data = process_xml(file_name)

#     elif file_type == "pdf":
#         data = process_pdf(file_name)

#     else:
#         print("❌ Unsupported file type")
#         return


def main(file_name):
    file_type = detect_file_type(file_name)

    if file_type not in SUPPORTED_FILE_TYPES:
        print("❌ Unsupported file type")
        return

    data = PROCESSOR_MAP[file_type](file_name)

    create_output(file_name, data)

  



