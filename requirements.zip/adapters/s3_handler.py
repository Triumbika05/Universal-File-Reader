import boto3

s3 = boto3.client('s3')

def upload_file(bucket, local_path, s3_key):
    s3.upload_file(local_path, bucket, s3_key)

def download_file(bucket, s3_key, local_path):
    s3.download_file(bucket, s3_key, local_path)
