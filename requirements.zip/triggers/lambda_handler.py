from core.pipeline import run_pipeline
from adapters.s3_handler import download_file, upload_file
from config import BUCKET_NAME, PROCESSED_PREFIX
import os

def lambda_handler(event, context):
    try:
        # Step 1: Get S3 file details
        record = event['Records'][0]
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']

        print(f"📥 File received: {key}")

        # Step 2: Download file locally
        file_name = os.path.basename(key)
        local_path = f"/tmp/{file_name}"

        download_file(bucket, key, local_path)

        # Step 3: Process file
        output_file = run_pipeline(local_path)

        # Step 4: Upload processed file
        upload_file(bucket, output_file, f"{PROCESSED_PREFIX}{output_file}")

        print("✅ Processing completed")

    except Exception as e:
        print("❌ Error:", e)
        raise e
