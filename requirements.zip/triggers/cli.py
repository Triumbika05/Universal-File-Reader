import sys
from core.pipeline import run_pipeline
from adapters.s3_handler import upload_file
from config import BUCKET_NAME, RAW_PREFIX, PROCESSED_PREFIX

def main():
    file_path = sys.argv[1]

    # Step 1: Upload raw
    file_name = file_path.split("/")[-1]
    upload_file(BUCKET_NAME, file_path, f"{RAW_PREFIX}{file_name}")

    # Step 2: Process
    output_file = run_pipeline(file_path)

    # Step 3: Upload processed
    upload_file(BUCKET_NAME, output_file, f"{PROCESSED_PREFIX}{output_file}")

    print("✅ Full pipeline completed")

if __name__ == "__main__":
    main()
