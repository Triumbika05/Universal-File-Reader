# from upload_to_s3 import upload_file
# # from processor import detect_file_type, process_csv, process_txt, process_xml, process_pdf, create_output
# from processor import main

# def run_pipeline(file_path):
#     print("🚀 Starting pipeline...")

#     # Step 1: Upload to S3
#     print("📤 Uploading to S3...")
#     upload_file(file_path)

#     # Step 2: Process file
#     print("⚙️ Processing file...")
#     file_type = detect_file_type(file_path)

#     if file_type == "csv":
#         data = process_csv(file_path)

#     elif file_type == "txt":
#         data = process_txt(file_path)

#     elif file_type == "xml":
#         data = process_xml(file_path)

#     elif file_type == "pdf":
#         data = process_pdf(file_path)

#     else:
#         print("❌ Unsupported file type")
#         return

#     # Step 3: Create output
#     create_output(file_path, data)

#     print("✅ Pipeline completed successfully!")


# if __name__ == "__main__":
#     file_path = "employee_data.csv"   # 👉 can change dynamically
#     run_pipeline(file_path)

# import boto3
# import os
# from config import BUCKET_NAME, PROCESSED_PREFIX, FAILED_PREFIX


# from adapters.upload_to_s3 import upload_file
# from processors.processor import main
# s3 = boto3.client('s3')

# # def run_pipeline(file_path):
# #     print("🚀 Starting pipeline...")

# #     # Step 1: Upload to S3
# #     print("📤 Uploading to S3...")
# #     upload_file(file_path)

# #     # Step 2: Process file
# #     print("⚙️ Processing file...")
# #     main(file_path)

# #     print("✅ Pipeline completed successfully!")
# def run_pipeline(file_path):
#     print("🚀 Starting pipeline...")

#     try:
#         # Step 1: Upload raw file
#         print("📤 Uploading to S3...")
#         upload_file(file_path)

#         # Step 2: Process file
#         print("⚙️ Processing file...")
#         main(file_path)

#         # Step 3: Upload processed output
#         output_file = f"{os.path.splitext(file_path)[0]}_output.json"

#         print("📤 Uploading processed file to S3...")
#         s3.upload_file(output_file, BUCKET_NAME, f"{PROCESSED_PREFIX}{output_file}")

#         print("✅ Pipeline completed successfully!")

#     except Exception as e:
#         print("❌ Error occurred:", e)

#         # Upload failed file
#         print("📤 Moving file to failed/")
#         s3.upload_file(file_path, BUCKET_NAME, f"{FAILED_PREFIX}{file_path}")


# if __name__ == "__main__":
#     import sys

#     file_path = sys.argv[1]   # ✅ dynamic input
#     run_pipeline(file_path)

from processors.processor import PROCESSOR_MAP, detect_file_type, create_output

def run_pipeline(file_path):
    print("🚀 Processing started...")

    file_type = detect_file_type(file_path)

    if file_type not in PROCESSOR_MAP:
        raise ValueError("Unsupported file type")

    data = PROCESSOR_MAP[file_type](file_path)

    output_file = create_output(file_path, data)

    print("✅ Processing completed")

    return output_file

